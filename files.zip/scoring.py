from __future__ import annotations

import re

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# A reasonably broad, lower-cased list of common tech / professional skills.
# Extend this list to tune what the tool is able to recognise.
SKILL_KEYWORDS: list[str] = [
    "python", "java", "javascript", "typescript", "c++", "c#", "go", "golang",
    "rust", "ruby", "php", "swift", "kotlin", "scala", "r",
    "html", "css", "sql", "nosql", "graphql",
    "react", "angular", "vue", "next.js", "node.js", "node", "django", "flask",
    "fastapi", "spring", "express",
    "aws", "azure", "gcp", "docker", "kubernetes", "terraform", "ci/cd",
    "linux", "git", "github", "gitlab", "jenkins",
    "pandas", "numpy", "scikit-learn", "tensorflow", "pytorch", "keras",
    "machine learning", "deep learning", "nlp", "data science", "data analysis",
    "data engineering", "etl", "airflow", "spark", "hadoop",
    "postgresql", "mysql", "mongodb", "redis", "elasticsearch",
    "rest api", "microservices", "agile", "scrum", "jira",
    "project management", "product management", "communication", "leadership",
    "problem solving", "teamwork", "excel", "tableau", "power bi",
]

_TOKEN_RE = re.compile(r"[a-zA-Z0-9+#.\-]+")


def _normalize(text: str) -> str:
    return (text or "").lower()


def extract_skills(text: str) -> set[str]:
    """Return the subset of SKILL_KEYWORDS found in the given text."""
    normalized = _normalize(text)
    found: set[str] = set()
    for skill in SKILL_KEYWORDS:
        pattern = r"(?<![a-zA-Z0-9])" + re.escape(skill) + r"(?![a-zA-Z0-9])"
        if re.search(pattern, normalized):
            found.add(skill)
    return found


def _semantic_scores(job_description: str, resume_texts: list[str]) -> list[float]:
    """TF-IDF cosine similarity between the job description and each resume."""
    documents = [job_description] + resume_texts

    try:
        vectorizer = TfidfVectorizer(stop_words="english")
        matrix = vectorizer.fit_transform(documents)
    except ValueError:
        # Happens when the vocabulary is empty after stop-word removal
        # (e.g. extremely short inputs). Fall back to no similarity signal.
        return [0.0 for _ in resume_texts]

    job_vector = matrix[0:1]
    resume_vectors = matrix[1:]
    similarities = cosine_similarity(job_vector, resume_vectors)[0]
    return [float(score) for score in similarities]


def rank_candidates(job_description: str, resumes: list[dict[str, str]]) -> pd.DataFrame:
    """
    Rank candidates against a job description.

    `resumes` is a list of {"name": ..., "text": ...} dictionaries.
    Returns a DataFrame sorted by final_score (descending) with columns:
    name, final_score, semantic_score, skill_score, matched_skills, missing_skills
    """
    if not resumes:
        return pd.DataFrame(
            columns=[
                "name",
                "final_score",
                "semantic_score",
                "skill_score",
                "matched_skills",
                "missing_skills",
            ]
        )

    required_skills = extract_skills(job_description)
    resume_texts = [resume["text"] for resume in resumes]
    semantic_scores = _semantic_scores(job_description, resume_texts)

    rows = []
    for resume, semantic_score in zip(resumes, semantic_scores):
        candidate_skills = extract_skills(resume["text"])
        matched = sorted(required_skills & candidate_skills)
        missing = sorted(required_skills - candidate_skills)

        skill_score = (len(matched) / len(required_skills)) if required_skills else 0.0
        final_score = (0.6 * semantic_score) + (0.4 * skill_score)

        rows.append(
            {
                "name": resume["name"],
                "final_score": final_score,
                "semantic_score": semantic_score,
                "skill_score": skill_score,
                "matched_skills": ", ".join(matched) if matched else "—",
                "missing_skills": ", ".join(missing) if missing else "—",
            }
        )

    df = pd.DataFrame(rows)
    df = df.sort_values(by="final_score", ascending=False).reset_index(drop=True)
    return df
