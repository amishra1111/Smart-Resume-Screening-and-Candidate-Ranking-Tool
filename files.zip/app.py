from __future__ import annotations

import re

from flask import Flask, render_template, request

from src.scoring import rank_candidates

app = Flask(__name__)


def parse_resume_entries(raw_entries: str) -> list[dict[str, str]]:
    text = (raw_entries or "").strip()
    if not text:
        raise ValueError("Please paste at least one candidate resume.")

    blocks = re.split(r"(?:\n\s*---\s*\n|\n\s*-----\s*\n)", text)
    resumes: list[dict[str, str]] = []

    for block in blocks:
        block = block.strip()
        if not block:
            continue

        lines = [line.rstrip() for line in block.splitlines()]
        if not lines:
            continue

        name = lines[0].strip() or f"Candidate {len(resumes) + 1}"
        resume_text = "\n".join(lines[1:]).strip()

        if not resume_text:
            continue

        resumes.append({"name": name, "text": resume_text})

    if not resumes:
        raise ValueError("Use the format: Name / Resume / separator ---")

    return resumes


@app.route("/", methods=["GET", "POST"])
def index():
    results = []
    summary = None
    error = None

    if request.method == "POST":
        job_description = (request.form.get("job_description") or "").strip()
        resume_entries = request.form.get("resume_entries") or ""

        if not job_description:
            error = "Please enter a job description."
        else:
            try:
                resumes = parse_resume_entries(resume_entries)
                ranked = rank_candidates(job_description, resumes)
                results = ranked.to_dict(orient="records")

                for row in results:
                    row["final_score"] = round(float(row["final_score"]) * 100, 2)
                    row["semantic_score"] = round(float(row["semantic_score"]) * 100, 2)
                    row["skill_score"] = round(float(row["skill_score"]) * 100, 2)

                if results:
                    summary = results[0]
            except Exception as exc:
                error = str(exc)

    return render_template(
        "index.html",
        results=results,
        summary=summary,
        error=error,
        job_description=request.form.get("job_description", "") if request.method == "POST" else "",
    )


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
